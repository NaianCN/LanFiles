@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
title LAN File Transfer
cd /d "%~dp0"
python\python.exe transfer.py
pause
